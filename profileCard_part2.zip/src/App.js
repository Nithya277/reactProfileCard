import "./styles.css";

const skills = [
  {
    skill: "HTML+CSS",
    level: "advanced",
    color: "#DC2929"
  },
  {
    skill: "Java Script",
    level: "advanced",
    color: "#2B29DC"
  },
  {
    skill: "Node JS",
    level: "intermediate",
    color: "#4CDC29"
  },
  {
    skill: "Git",
    level: "intermediate",
    color: "#EAD067"
  },
  {
    skill: "React JS",
    level: "beginner",
    color: "#E667EA"
  }
];
export default function App() {
  return (
    <div className="card">
      <Avatar profilePath={"profile.png"} altText={"A closer shot of Nithya"} />

      <div className="data">
        <Intro
          userName={"Nithya Nataraaj"}
          bio={
            "8.3 years of experience in front end development.Involved in requirement analysis, estimation, and design discussions with UX experts, peer review and manual testing."
          }
        />
        <SkillSetList />
      </div>
    </div>
  );
}
function Avatar(props) {
  return <img src={props.profilePath} alt={props.altText} />;
}

function Intro(props) {
  return (
    <div>
      <h2>{props.userName}</h2>
      <p>{props.bio}</p>
    </div>
  );
}

function SkillSetList() {
  return (
    <div className="skill-list">
      {skills.map((skill) => (
        <Skillset skill={skill.skill} level={skill.level} color={skill.color} />
      ))}
      {/* <Skillset skill={"HTML5+CSS3"} emoji={"💪"} color={"blue"} /> */}
    </div>
  );
}
function Skillset({ skill, level, color }) {
  return (
    <div style={{ backgroundColor: color }}>
      <span>{skill}</span>
      <span>
        {level === "beginner" && "👶"}
        {level === "intermediate" && "👍"}
        {level === "advanced" && "💪"}
      </span>
    </div>
  );
}
