import "./styles.css";

export default function App() {
  return (
    <div className="card">
      <Avatar profilePath={"profile.png"} altText={"A closer shot of Nithya"} />

      <div className="data">
        <Intro
          userName={"Nithya Nataraaj"}
          bio={
            "8.3 years of experience in front end development.Involved in requirement analysis, estimation, and design discussions with UX experts, peer review and manual testing."
          }
        />
        <SkillSetList />
      </div>
    </div>
  );
}
function Avatar(props) {
  return <img src={props.profilePath} alt={props.altText} />;
}

function Intro(props) {
  return (
    <div>
      <h2>{props.userName}</h2>
      <p>{props.bio}</p>
    </div>
  );
}

function SkillSetList() {
  return (
    <div className="skill-list">
      <Skillset skill={"HTML5+CSS3"} emoji={"💪"} color={"blue"} />
      <Skillset skill={"Java script"} emoji={"💪"} color={"red"} />
      <Skillset skill={"NodeJS"} emoji={"💪"} color={"green"} />
      <Skillset skill={"Git"} emoji={"💪"} color={"orange"} />
      <Skillset skill={"EXT Js"} emoji={"💪"} color={"aqua"} />
    </div>
  );
}
function Skillset(props) {
  return (
    <div style={{ backgroundColor: props.color }}>
      <span>{props.skill}</span>
      <span>{props.emoji}</span>
    </div>
  );
}
